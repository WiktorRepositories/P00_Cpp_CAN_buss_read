#include <stdint.h>

#ifndef _CUSTOM_STRUCTURES_H
#define _CUSTOM_STRUCTURES_H

/*****************************************************************************
 * @name    Structures for LCD screen switch
*/
typedef struct 
{
    uint8_t numberOfScreen;
    uint8_t limitValuesOfparametr;
    uint8_t numberOfParametr;
    uint8_t incOrDecCurentparameter;
    int16_t cuurentParam;
}LCD_ENC_interface_t;
//============================================================================

/*****************************************************************************
 * @name    Structures for menu menagment
*/
typedef struct 
{
    uint8_t inA;
    uint8_t inB;
    uint8_t rotDir;
}ENC_t;
//============================================================================

/*****************************************************************************
 * @name    Structures for CAN undecoded data
*/
#define CAN_DATA_MAX_LEN 0x10
typedef struct 
{
    unsigned long ID;
    uint8_t arrData[CAN_DATA_MAX_LEN];
}CAN_data_undecoded_t;
//============================================================================

/*****************************************************************************
 * @name    Structures for CAN decoded data
*/
typedef struct 
{// Basic memeber of type uint8_t
    uint8_t max;
    uint8_t value;
    uint8_t min;
    uint8_t fault;
}valueParameters_uint8_t;

typedef struct 
{// Basic memeber of type int16_t
    int16_t max;
    int16_t value;
    int16_t min;
    uint8_t fault;
}valueParameters_int16_t;

typedef struct 
{// Basic memeber of type float
    float max;
    float value;
    float min;
    uint8_t fault;
}valueParameters_float_t;

typedef struct
{// Structures collection for package1
    valueParameters_int16_t   RPM;  // 2Byte RPM (0-16000rpm)
    valueParameters_uint8_t   TPS;  // 1B TPS (0-100%)
    valueParameters_uint8_t   IAT;  // 1B IAT (-40-127 C)
    valueParameters_int16_t   MAP;  // 2B MAP (0-600 kPa)
    valueParameters_int16_t   VSPD; // 2Byte VSPD (0-400 km/h)
}CanData1_t;

typedef struct
{// Structures collection for package2
    valueParameters_int16_t  AIN1;  // 2B AIN #1 (0-5 V)
    valueParameters_int16_t  AIN2;  // 2B AIN #2 (0-5 V)
    valueParameters_int16_t  AIN3;  // 2B AIN #3 (0-5 V)
    valueParameters_int16_t  AIN4;  // 2B AIN #4 (0-5 V)
}CanData2_t;

typedef struct
{// Structures collection for package3
    valueParameters_int16_t  GPS_Speed;// 2Byte VSPD (0-400 km/h)
    valueParameters_uint8_t  BARO;   // 1B BARO (50-130 kPa)
    valueParameters_uint8_t  OILT;   // 1B OILT (0-160 C)
    valueParameters_uint8_t  OILP;   // 1B OILP (0-12 Bar)
    valueParameters_uint8_t  FUELP;  // 1B FUELP (0-7 Bar)
    valueParameters_int16_t  CLT;    // 2B CLT (-40 - 250 C)
}CanData3_t;

typedef struct 
{// Structures collection for package4
    valueParameters_uint8_t  Ign_Angle;// 1B Ign Angle (-60-60 Deg) 0.5deg/bit
    valueParameters_uint8_t  Dwell;  // 1B DWELL (0-10 ms)
    valueParameters_uint8_t  Lambda; // 1B LAMBDA (0-2 Lambda)
    valueParameters_uint8_t  AFR;    // 1B LAMBDA Correction (75-12t %)
    valueParameters_int16_t  EGT_1;  // 2B EGT1 (0-1100 C)
    valueParameters_int16_t  EGT_2;  // 2B EGT1 (0-1100 C)
}CanData4_t;

typedef struct 
{// Structures collection for package5
    valueParameters_uint8_t  Gear;      // 1B Gear ( 0 - 7 )
    valueParameters_uint8_t  ECU_Temp;  // 1B ECU TEMP (-40 - 120 C)
    valueParameters_int16_t  Battery;   // 2B BATTery (0-20 V)
}CanData5_t;

typedef struct 
{// Structures collection for package6
    valueParameters_uint8_t  DBW_Pos;    // 1B DBW Pos ( 0 - 100 % )
    valueParameters_uint8_t  DBW_Target; // 1B DBW TRGT ( 0 - 100 % )
    valueParameters_int16_t  TC_DRPM_RAW;// 2B TC DRPM RAW (0-1000)
    valueParameters_int16_t  TC_DRPM;    // 2B TC DRPM (0-400)
    valueParameters_uint8_t  TC_TORQ_REDU;// 1B TC Torque Reduction (0-100 %)
    valueParameters_uint8_t  PIT_TRQ_REDU;// 1B PIT Limit torque reduction (0-100 %)
}CanData6_t;

typedef struct 
{// Structures collection for package7
    valueParameters_int16_t  AIN5;       // 2B AIN #5 ( 0 - 5 V )
    valueParameters_int16_t  AIN6;       // 2B AIN #6 ( 0 - 5 V )
    valueParameters_uint8_t  OUT_FLAG1;  // 1B OUT FLAGS1 (see EMU Manual)
    valueParameters_uint8_t  OUT_FLAG2;  // 1B OUT FLAGS2
    valueParameters_uint8_t  OUT_FLAG3;  // 1B OUT FLAGS3
    valueParameters_uint8_t  OUT_FLAG4;  // 1B OUT FLAGS4
}CanData7_t;
//============================================================================
#endif // _MY_INTERFACES_H