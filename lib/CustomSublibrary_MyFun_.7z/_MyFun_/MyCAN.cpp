#include "MyCAN.h"
/***************************************************************************************************
   @brief   Class constructor
   @param   pdata      Reference to outputdata. 
*/
DecodeCANDataClass::DecodeCANDataClass(CanData1_t* pCAN1, CanData2_t* pCAN2, CanData3_t* pCAN3, CanData4_t* pCAN4, CanData5_t* pCAN5, CanData6_t* pCAN6, CanData7_t* pCAN7):
    pPackage1(pCAN1),
    pPackage2(pCAN2),
    pPackage3(pCAN3),
    pPackage4(pCAN4),
    pPackage5(pCAN5),
    pPackage6(pCAN6),
    pPackage7(pCAN7) 
{}
//==================================================================================================

/***************************************************************************************************
   @brief   Class dekonctructor
   @param   pdata      Pointer to parameter type struture). 
*/
DecodeCANDataClass::~DecodeCANDataClass(void)
{;}
//==================================================================================================

/***************************************************************************************************
   @brief   Check paremeter value is it is in min max range
   @param   pdata      Pointer to parameter type struture). 
   @return  void
   @note    Posible imputs: uint8_t, int16_t, float
*/
void DecodeCANDataClass::CheckValues(valueParameters_uint8_t* pdata)
{
    if(pdata->value == 0x00) 
        {pdata->fault = MYCAN_ERROR_NO_DATA;}
    else if(pdata->value <= pdata->min) 
        {pdata->fault = MYCAN_ERROR_MIN;}
    else if(pdata->value >= pdata->max) 
        {pdata->fault = MYCAN_ERROR_MAX;}
    else 
        {pdata->fault = 0x00;}
}
//==================================================================================================

/***************************************************************************************************
   @brief   Check paremeter value is it is in min max range
   @param   pdata      Pointer to parameter type struture). 
   @return  void
   @note    Posible imputs: uint8_t, int16_t, float
*/
void DecodeCANDataClass::CheckValues(valueParameters_int16_t* pdata)
{
    if(pdata->value == 0x0000) 
        {pdata->fault = MYCAN_ERROR_NO_DATA;}
    else if(pdata->value <= pdata->min) 
        {pdata->fault = MYCAN_ERROR_MIN;}
    else if(pdata->value >= pdata->max) 
        {pdata->fault = MYCAN_ERROR_MAX;}
    else 
        {pdata->fault = 0x00;}
}
//==================================================================================================

/***************************************************************************************************
   @brief   Check paremeter value is it is in min max range
   @param   pdata      Pointer to parameter type struture). 
   @return  void
   @note    Posible imputs: uint8_t, int16_t, float
*/
void DecodeCANDataClass::CheckValues(valueParameters_float_t* pdata)
{
    if(pdata->value <= pdata->min) 
        {pdata->fault = MYCAN_ERROR_MIN;}
    else if(pdata->value >= pdata->max) 
        {pdata->fault = MYCAN_ERROR_MAX;}
    else 
        {pdata->fault = 0x00;}
}
//==================================================================================================

/***************************************************************************************************
   @brief   Coppy data from structure to structure
   @param   pSrcPtr Base pointer to source structure
   @param   pDestPtr Base pointer to destination structure
   @param   dataLenght Lenght data in byte. Use "sizeof()"
   @return  void
   @note    Double check data lenght
*/
void DecodeCANDataClass::MoveData(uint8_t* pSrcPtr, uint8_t* pDestPtr, uint8_t dataLenght)
{
    uint8_t i;
    for(i=0; i<dataLenght; i++)
    {
        *(pDestPtr + i) = *(pSrcPtr + i);
    }
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside pBuffer to valid parameters
   @param   pBuffer[]   CAN data pBuffer
   @return  void
   @note    Custom for package 1
*/
void DecodeCANDataClass::DecodePackage1(uint8_t* pBuffer)
{
    pPackage1->RPM.value = (int16_t)((pBuffer[0] << 8) | (pBuffer[1] << 0));
    pPackage1->TPS.value = (pBuffer[2]);
    pPackage1->IAT.value = (pBuffer[3]);
    pPackage1->MAP.value = (int16_t)((pBuffer[4] << 8) | (pBuffer[5] << 0));
    pPackage1->VSPD.value = (int16_t)((pBuffer[6] << 8) | (pBuffer[7] << 0));

    CheckValues(&(pPackage1->RPM));
    CheckValues(&(pPackage1->TPS));
    CheckValues(&(pPackage1->IAT));
    CheckValues(&(pPackage1->MAP));
    CheckValues(&(pPackage1->VSPD));
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside buffer to valid parameters
   @param   buffer[]   CAN data buffer
   @return  void
   @note    Custom for package 2
*/
void DecodeCANDataClass:: DecodePackage2(uint8_t* pBuffer)
{
    pPackage2->AIN1.value = (int16_t)((pBuffer[0] << 8) | (pBuffer[1] << 0));
    pPackage2->AIN2.value = (int16_t)((pBuffer[2] << 8) | (pBuffer[3] << 0));
    pPackage2->AIN3.value = (int16_t)((pBuffer[4] << 8) | (pBuffer[5] << 0));
    pPackage2->AIN4.value = (int16_t)((pBuffer[6] << 8) | (pBuffer[7] << 0));

    CheckValues(&(pPackage2->AIN1));
    CheckValues(&(pPackage2->AIN2));
    CheckValues(&(pPackage2->AIN3));
    CheckValues(&(pPackage2->AIN4));
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside pBuffer to valid parameters
   @param   pBuffer[]   CAN data pBuffer
   @return  void
   @note    Custom for package 3
*/
void DecodeCANDataClass::DecodePackage3(uint8_t* pBuffer)
{
    pPackage3->GPS_Speed.value   = (int16_t)((pBuffer[0] << 8) | (pBuffer[1] << 0));
    pPackage3->BARO.value        = (pBuffer[2]);
    pPackage3->OILT.value        = (pBuffer[3]);
    pPackage3->OILP.value        = (pBuffer[4] / 10);
    pPackage3->FUELP.value       = (pBuffer[5] / 10);
    pPackage3->CLT.value         = (int16_t)((pBuffer[6] << 8) | (pBuffer[7] << 0));

    CheckValues(&(pPackage3->GPS_Speed));
    CheckValues(&(pPackage3->BARO));
    CheckValues(&(pPackage3->OILT));
    CheckValues(&(pPackage3->OILP));
    CheckValues(&(pPackage3->FUELP));
    CheckValues(&(pPackage3->CLT));
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside pBuffer to valid parameters
   @param   pBuffer[]   CAN data pBuffer
   @return  void
   @note    Custom for package 4
*/
void DecodeCANDataClass::DecodePackage4(uint8_t* pBuffer)
{
    pPackage4->Ign_Angle.value  = (pBuffer[0]);
    pPackage4->Dwell.value      = (pBuffer[1]);
    pPackage4->Lambda.value     = (pBuffer[2]);
    pPackage4->AFR.value        = (pBuffer[3]);
    pPackage4->EGT_1.value      = (int16_t)((pBuffer[4] << 8) | (pBuffer[5] << 0));
    pPackage4->EGT_2.value      = (int16_t)((pBuffer[6] << 8) | (pBuffer[1] << 0));

    CheckValues(&(pPackage4->Lambda));
    CheckValues(&(pPackage4->AFR));
    CheckValues(&(pPackage4->EGT_1));
    CheckValues(&(pPackage4->EGT_2)); 
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside pBuffer to valid parameters
   @param   pBuffer[]   CAN data pBuffer
   @return  void
   @note    Custom for package 5
*/
/**************************************************************************/
void DecodeCANDataClass::DecodePackage5(uint8_t* pBuffer)
{
    pPackage5->Gear.value    = (pBuffer[0]);
    pPackage5->ECU_Temp.value= (pBuffer[1]);
    pPackage5->Battery.value = (int16_t)((pBuffer[2] << 8) | (pBuffer[3] << 0));

    CheckValues(&(pPackage5->Gear));
    CheckValues(&(pPackage5->ECU_Temp));
    CheckValues(&(pPackage5->Battery));
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside buffer to valid parameters
   @param   buffer[]   CAN data buffer
   @return  void
   @note    Custom for package 6
*/
/**************************************************************************/
void DecodeCANDataClass::DecodePackage6(uint8_t* pBuffer)
{
    pPackage6->DBW_Pos.value     = (pBuffer[0]);
    pPackage6->DBW_Target.value  = (pBuffer[1]);
    pPackage6->TC_DRPM_RAW.value = (int16_t)((pBuffer[2] << 8) | (pBuffer[3] << 0));
    pPackage6->TC_DRPM.value     = (int16_t)((pBuffer[4] << 8) | (pBuffer[5] << 0));
    pPackage6->TC_TORQ_REDU.value= (pBuffer[6]);
    pPackage6->PIT_TRQ_REDU.value= (pBuffer[7]);

    CheckValues(&(pPackage6->DBW_Pos));
    CheckValues(&(pPackage6->DBW_Target));
    CheckValues(&(pPackage6->TC_DRPM_RAW));
    CheckValues(&(pPackage6->TC_DRPM));
    CheckValues(&(pPackage6->PIT_TRQ_REDU));
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside buffer to valid parameters
   @param   pBuffer[]   CAN data pBuffer
   @return  void 
   @note    Custom for package 7
*/
/**************************************************************************/
void DecodeCANDataClass::DecodePackage7(uint8_t* pBuffer)
{
    pPackage7->AIN5.value = (int16_t)((pBuffer[0] << 8) | (pBuffer[1] << 0));
    pPackage7->AIN6.value = (int16_t)((pBuffer[2] << 8) | (pBuffer[3] << 0));
    pPackage7->OUT_FLAG1.value = (pBuffer[4]);
    pPackage7->OUT_FLAG2.value = (pBuffer[5]);
    pPackage7->OUT_FLAG3.value = (pBuffer[6]);
    pPackage7->OUT_FLAG4.value = (pBuffer[7]);

    CheckValues(&(pPackage7->AIN5));
    CheckValues(&(pPackage7->AIN6));
    CheckValues(&(pPackage7->OUT_FLAG1));
    CheckValues(&(pPackage7->OUT_FLAG2));
    CheckValues(&(pPackage7->OUT_FLAG3));
    CheckValues(&(pPackage7->OUT_FLAG4));
}
//==================================================================================================

/***************************************************************************************************
   @brief   Decodes CAN data inside pBuffer to valid parameters
   @param   void
   @return  Can ID uint16_t that have been decoded
   @note    When data comes it is decodec depend from ID
*/
void DecodeCANDataClass::CallForReadCanData(CAN_data_undecoded_t* pDataFromCan)
{           
    unsigned long tID;
    tID = pDataFromCan->ID;
    switch (tID)
    {
        case MYCAN_CAN_ID_1: // Data1 decode and write to global data
            DecodePackage1(pDataFromCan->arrData);
            break;

        case MYCAN_CAN_ID_2: // Data2 decode and write to global data
            DecodePackage2(pDataFromCan->arrData);
            break;

        case MYCAN_CAN_ID_3: // Data3 decode and write to global data
            DecodePackage3(pDataFromCan->arrData);
            break;

        case MYCAN_CAN_ID_4: // Data4 decode and write to global data
            DecodePackage4(pDataFromCan->arrData);
            break;

        case MYCAN_CAN_ID_5: // Data5 decode and write to global data
            DecodePackage5(pDataFromCan->arrData);
            break;

        case MYCAN_CAN_ID_6: // Data6 decode and write to global data
            DecodePackage6(pDataFromCan->arrData);
            break;

        case MYCAN_CAN_ID_7: // Data7 decode and write to global data
            DecodePackage7(pDataFromCan->arrData);
            break;
        
        default:
            break;
    }
}
//==================================================================================================

/***************************************************************************************************
   @brief   CAN communication procedure used pointer to MCP_CAN class 
   @param   refMcpCan Reference to MCP_CAN class
   @param   pCanData Pointer of type (CAN_data_t*)
   @return  void
   @note    This function decodes CAN data to global structure
*/
void ReadCanDataBy_MCP_CAN(MCP_CAN* pMcpCan, CAN_data_undecoded_t* pCanData)
{ 
  byte  tLen;
  byte* pBuffer; 

  if(CAN_MSGAVAIL != pMcpCan->checkReceive()) 
  { // Data is not recieved
    // Error code is assigned
    pCanData->ID = (unsigned long)(-1);
  }
  else
  { // Data is recieved
    tLen    = CAN_DATA_MAX_LEN;
    pBuffer = (byte*)(pCanData->arrData);

    pMcpCan->readMsgBuf(&tLen, pBuffer);
    pCanData->ID = pMcpCan->getCanId();
  }
}
//==================================================================================================
