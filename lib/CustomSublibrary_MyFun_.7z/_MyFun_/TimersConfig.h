#include "Arduino.h"

#ifndef _TIMERS_CONFIG_H
#define _TIMERS_CONFIG_H

#define MASK_TRUE_BIT_00    0x01
#define MASK_TRUE_BIT_01    0x02
#define MASK_TRUE_BIT_02    0x04
#define MASK_TRUE_BIT_03    0x08
#define MASK_TRUE_BIT_04    0x10
#define MASK_TRUE_BIT_05    0x20
#define MASK_TRUE_BIT_06    0x40
#define MASK_TRUE_BIT_07    0x80

#define MASK_FALS_BIT_00    0xFE
#define MASK_FALS_BIT_01    0xFD
#define MASK_FALS_BIT_02    0xFB
#define MASK_FALS_BIT_03    0xF7
#define MASK_FALS_BIT_04    0xEF
#define MASK_FALS_BIT_05    0xDF
#define MASK_FALS_BIT_06    0xBF
#define MASK_FALS_BIT_07    0x7F

#define MYCFG_TIMER_T2_PRESCALER_1024x    0xA
#define MYCFG_TIMER_T2_PRESCALER_0256x    0x8
#define MYCFG_TIMER_T2_PRESCALER_0064x    0x6
#define MYCFG_TIMER_T2_PRESCALER_0008x    0x3
#define MYCFG_TIMER_T2_PRESCALER_0001x    0x0

#define MYCFG_TIMER_T2_MODE_NORMAL        0x11
#define MYCFG_TIMER_T2_MODE_PWM           0x11
#define MYCFG_TIMER_T2_MODE_CTF           0x33
#define MYCFG_TIMER_T2_MODE_COMPARE       0x44

/*************************************************************************
* @fn          SetupTimerT2
* @brief       Setup configuration for 8 bit timer T2 interrupt
* @param       inRegCmpVal Value for compare mode
* @param       inMODE Timer operation mode: normal, compare etc
* @param       inPresShift Prescaler value
* @return      void
* @note        For normal mode first parametr is not important
*/
void SetupTimerT2(uint8_t inRegCmpVal,uint8_t inMODE, uint8_t inPresShift);


bool TimerCounter(uint8_t* pCounter, uint8_t inOVdat);

#endif // _TIMERS_CONFIG_H